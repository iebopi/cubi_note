ifconfig eth1 10.21.1.99
ifconfig eth0 10.21.1.98
#sleep 10
vsftpd &
echo "done!"
