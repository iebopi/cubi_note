chown root:root /etc/vsftpd.conf
mkdir -p /usr/share/empty
#passwd << EOF
#root
#root
#EOF
vsftpd &

