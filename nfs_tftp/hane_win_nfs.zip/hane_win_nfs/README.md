# Crack
Registration name: astray.cn
License Key: Get from Keygen.exe

# Exports example
d:\sharedir -name:share

# Mount
windows: mount 127.0.0.1:/share Z:
linux:   mount -t nfs -o nolock 127.0.0.1:/share /mnt